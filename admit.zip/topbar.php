
<style>
    #leftLogo{
        margin-top: 50px;
        margin-right: 40px;
        border-radius: 15px;
    }
    #rightLogo{
        margin-top: 50px;
        margin-right: 40px;
        border-radius: 15px;
    }
</style>

<div class="container-fluid bg-gradient-info" style="background:linear-gradient(-20deg, gray 25%, transparent 100%)">
        <div class="row">
            <div class="col-2 ">
            <img src="all_image/logo.jpeg" id="leftLogo" height="100px" width="90%" alt="">
               
            </div>
            <div class="col-8">
                <h5 class="mt-4 text-center" style=" font-size: 54px; font-family:cursive">Rangpur Govt College, Rangpur.</h5>
                <h3 class="text-center">Education | Morality | Discipline</h3>
                <h3 style="text-align: center;"> College Code : 127508 | EIIN: 127511</h3>
            </div>
            <div class="col-2">
            <img src="all_image/logo.jpeg" id="rightLogo" height="100px" width="90%" alt="">
            </div>
        </div>
    </div>