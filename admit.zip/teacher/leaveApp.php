

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">


<div class="container">
    <div class="row">
        <div class="col">
            <form action="" method="post">
                <div class="row">
                    <div class="col-5">
                        <h4> Leave Reason</h4>
                    </div>
                    <div class="col-7">
                        <input type="text" class="form-control" name="lreason" placeholder="input leave reason">
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-5">
                        <h4>Description</h4>
                    </div>
                    <div class="col-7" >
                       <textarea name="" id="" cols="30" class='form-control' rows="4" placeholder="text description for your your leave"></textarea>
                    </div>
                </div>
                <div class="row mt-2">
                        <div class="col ">
                            <input type="submit" class="form-control bg-secondary text-light tex-center"  name="leaveapp" value="Application for leave">
                        </div>
                </div>
            </form>
        </div>
    </div>
</div>